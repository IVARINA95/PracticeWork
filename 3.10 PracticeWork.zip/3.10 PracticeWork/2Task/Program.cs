﻿using System;

namespace _2Task
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Приветствуем в игре '21'");
            Console.ReadKey();
            Console.WriteLine("Сколько у вас карт в руке?");
            int amountCards = int.Parse(Console.ReadLine());

            if (amountCards == 1) //вывод в зависимости от кол-ва карт
                Console.WriteLine($"Отлично! У вас на руках {amountCards} карта!");
            else if (amountCards > 4)
                Console.WriteLine($"Отлично! У вас на руках {amountCards} карт!");
            else if (amountCards == 0)
                Console.WriteLine("К сожалению, у вас на руках нет ни одной карты! Начните заново!");
            else
                Console.WriteLine($"Отлично! У вас на руках {amountCards} карты!");

            Console.WriteLine("Введите номинал карты, где Валет = J, Дама = Q, Король = K, Туз = T равны 10");

            int sumCard = 0; // ввод переменной Сумма карт
            for (int cards = 0; cards < amountCards; cards++) //цикл ввода номинала карт
            {
                //int Card;

                //if (Console.ReadLine() == "q") Card = 10;
                //if (Console.ReadLine() == "j") Card = 10;
                //if (Console.ReadLine() == "k") Card = 10;
                //if (Console.ReadLine() == "a") Card = 10;

               int  Card = int.Parse(Console.ReadLine());


                switch (amountCards)
                {
                    case 1:
                        sumCard = sumCard + Card;
                        
                        break;
                    case 2:
                        sumCard = sumCard + Card;
                        
                        break;
                    case 3:
                        sumCard = sumCard + Card;
                        if (sumCard >= 22) Console.WriteLine("Вы проиграли!");
                        if (sumCard == 21) Console.WriteLine("Вы выиграли!");
                        
                        break;
                    case 4:
                        sumCard = sumCard + Card;
                        if (sumCard > 22) Console.WriteLine("Вы проиграли!");
                        if (sumCard == 21) Console.WriteLine("Вы выиграли!");
                        
                        break;
                    case 5:
                        sumCard = sumCard + Card;
                        if (sumCard > 22) Console.WriteLine("Вы проиграли!");
                        if (sumCard == 21) Console.WriteLine("Вы выиграли!");
                        
                        break;
                    case 6:
                        if (sumCard > 22) Console.WriteLine("Вы проиграли!");
                        if (sumCard == 21) Console.WriteLine("Вы выиграли!");
                        sumCard = sumCard + Card;
                        
                        break;
                }
                
            }
            Console.WriteLine($"Сумма очков {sumCard}");
            if (sumCard < 21) Console.WriteLine("У вас недостаточно карт. Попробуйте снова");
        }
    }
}
