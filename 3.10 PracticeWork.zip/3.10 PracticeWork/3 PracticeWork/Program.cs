﻿using System;

namespace _3_PracticeWork
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите любое число");

            int num = int.Parse(Console.ReadLine()); //ввод числа пользователем
            float div;
            bool isPrime = false;

            for (int i = 2; i < num; i++) // перебор числа от 1 до num - 1
            {
                Console.WriteLine($"{i}");
                do
                {
                    div = num % i;
                    if (num % i == 0)
                    {
                        Console.WriteLine($" число {num} - делится на {i}");
                        isPrime = true;
                        break;
                    }

                } while (num % i == 0);
            }
            if(isPrime == false)
            {
                Console.WriteLine($"{num} - простое число");
            }
            else Console.WriteLine($"{num} - не простое число");

            Console.ReadKey();

            //if (num % num == 0)
            //    Console.WriteLine($"{num} - простое число");
            //else
            //    Console.WriteLine($"{num} - не простое число");
            //if (num % (i - 1) == 0) check = true;

            

        }
        
    }
}
