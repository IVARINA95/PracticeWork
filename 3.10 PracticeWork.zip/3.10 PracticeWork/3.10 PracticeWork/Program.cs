﻿using System;

namespace _3._10_PracticeWork
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите любое число");

            int num = int.Parse(Console.ReadLine());
            if ( num % 2 == 0)
            {
                Console.WriteLine($"{num} - четное число!");
            }
            else
            {
                Console.WriteLine($"{num} - нечетное число!");
            }

            Console.ReadKey();
        }
    }
}
