﻿using System;

namespace _1_PracriceWork
{
    class Program
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!"); // вывод в консоль "Hello World!"
            Console.ReadKey(); //нажать любую кнопку для выхода из консоли
        }
    }
}
