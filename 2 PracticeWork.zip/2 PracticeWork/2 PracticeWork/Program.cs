﻿using System;

namespace _2_PracticeWork
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Hello ");
            Console.Write("World ");
            Console.Write("!!!");
            Console.ReadLine();
        }
    }
}
